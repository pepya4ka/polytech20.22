#ifndef LAB4_3_H_
#define LAB4_3_H_
	typedef int data_sc;
	#define N 16384
	void foo_b(int data_in[N], int scale[3], int data_out1[N], int data_out2[N]);
	void foo_m(int data_in[N], int scale[3], int data_out1[N], int data_out2[N]); 	
#endif

