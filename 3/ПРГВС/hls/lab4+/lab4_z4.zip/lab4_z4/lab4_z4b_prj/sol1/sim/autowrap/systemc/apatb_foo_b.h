// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_foo_b (
int data_in[16384],
int scale[3],
int data_out[16384]);
