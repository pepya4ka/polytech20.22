#ifndef LAB4_5_H_
#define LAB4_5_H_
	typedef int data_sc;
	#define N 16384
	void foo_b(int data_in[N], int data_out[N], int scale[2], char sel);
	void foo_m(int data_in[N], int data_out[N], int scale[2], char sel); 	
#endif

