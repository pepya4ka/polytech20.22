#define N 128

typedef int atype;
