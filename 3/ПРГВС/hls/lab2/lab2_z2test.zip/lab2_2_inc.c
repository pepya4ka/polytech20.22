#define N 8192

typedef int atype;
