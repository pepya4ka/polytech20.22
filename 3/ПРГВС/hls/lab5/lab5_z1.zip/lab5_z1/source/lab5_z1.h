
#ifndef LAB5_Z1_H_
#define LAB5_Z1_H_
 
#include <stdio.h>

#define N 131072

void lab5_z1(int d_in[N], int d_out[N/4]);

#endif
