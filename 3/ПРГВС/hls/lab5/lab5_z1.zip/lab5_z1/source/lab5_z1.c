#include "lab5_z1.h"

void lab5_z1(int d_in[N], int d_out[N/4])
{
	for_label0: for(int i = 0; i < N/4; ++i) {
		d_out[i] = d_in[i] + d_in[i + N/4] + d_in[i+N/2] + d_in[i+(3*N)/4];
	} 

}






