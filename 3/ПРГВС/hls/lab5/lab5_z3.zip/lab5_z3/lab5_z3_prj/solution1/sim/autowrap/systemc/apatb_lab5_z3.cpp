// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================

#include <systemc>
#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <stdint.h>
#include "SysCFileHandler.h"
#include "ap_int.h"
#include "ap_fixed.h"
#include <complex>
#include <stdbool.h>
#include "autopilot_cbe.h"
#include "hls_stream.h"
#include "hls_half.h"
#include "hls_signal_handler.h"

using namespace std;
using namespace sc_core;
using namespace sc_dt;


// [dump_struct_tree [build_nameSpaceTree] dumpedStructList] ---------->
    typedef struct {
        int A[262144];
        int B[262144];
       } data;



// [dump_enumeration [get_enumeration_list]] ---------->


// wrapc file define: "d_in_A"
#define AUTOTB_TVIN_d_in_A  "../tv/cdatafile/c.lab5_z3.autotvin_d_in_A.dat"
// wrapc file define: "d_in_B"
#define AUTOTB_TVIN_d_in_B  "../tv/cdatafile/c.lab5_z3.autotvin_d_in_B.dat"
// wrapc file define: "d_out_A"
#define AUTOTB_TVOUT_d_out_A  "../tv/cdatafile/c.lab5_z3.autotvout_d_out_A.dat"
#define AUTOTB_TVIN_d_out_A  "../tv/cdatafile/c.lab5_z3.autotvin_d_out_A.dat"
// wrapc file define: "d_out_B"
#define AUTOTB_TVOUT_d_out_B  "../tv/cdatafile/c.lab5_z3.autotvout_d_out_B.dat"
#define AUTOTB_TVIN_d_out_B  "../tv/cdatafile/c.lab5_z3.autotvin_d_out_B.dat"

#define INTER_TCL  "../tv/cdatafile/ref.tcl"

// tvout file define: "d_out_A"
#define AUTOTB_TVOUT_PC_d_out_A  "../tv/rtldatafile/rtl.lab5_z3.autotvout_d_out_A.dat"
// tvout file define: "d_out_B"
#define AUTOTB_TVOUT_PC_d_out_B  "../tv/rtldatafile/rtl.lab5_z3.autotvout_d_out_B.dat"

class INTER_TCL_FILE {
	public:
		INTER_TCL_FILE(const char* name) {
			mName = name;
			d_in_A_depth = 0;
			d_in_B_depth = 0;
			d_out_A_depth = 0;
			d_out_B_depth = 0;
			trans_num =0;
		}

		~INTER_TCL_FILE() {
			mFile.open(mName);
			if (!mFile.good()) {
				cout << "Failed to open file ref.tcl" << endl;
				exit (1);
			}
			string total_list = get_depth_list();
			mFile << "set depth_list {\n";
			mFile << total_list;
			mFile << "}\n";
			mFile << "set trans_num "<<trans_num<<endl;
			mFile.close();
		}

		string get_depth_list () {
			stringstream total_list;
			total_list << "{d_in_A " << d_in_A_depth << "}\n";
			total_list << "{d_in_B " << d_in_B_depth << "}\n";
			total_list << "{d_out_A " << d_out_A_depth << "}\n";
			total_list << "{d_out_B " << d_out_B_depth << "}\n";
			return total_list.str();
		}

		void set_num (int num , int* class_num) {
			(*class_num) = (*class_num) > num ? (*class_num) : num;
		}
	public:
		int d_in_A_depth;
		int d_in_B_depth;
		int d_out_A_depth;
		int d_out_B_depth;
		int trans_num;

	private:
		ofstream mFile;
		const char* mName;
};

extern "C" void lab5_z3 (
data d_in,
data* d_out);

extern "C" void AESL_WRAP_lab5_z3 (
data d_in,
data* d_out)
{
	refine_signal_handler();
	fstream wrapc_switch_file_token;
	wrapc_switch_file_token.open(".hls_cosim_wrapc_switch.log");
	int AESL_i;
	if (wrapc_switch_file_token.good())
	{
		CodeState = ENTER_WRAPC_PC;
		static unsigned AESL_transaction_pc = 0;
		string AESL_token;
		string AESL_num;
		static AESL_FILE_HANDLER aesl_fh;


		// output port post check: "d_out_A"
		aesl_fh.read(AUTOTB_TVOUT_PC_d_out_A, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_d_out_A, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_d_out_A, AESL_token); // data

			sc_bv<2048> *d_out_A_pc_buffer = new sc_bv<2048>[4096];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'd_out_A', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'd_out_A', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					d_out_A_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_d_out_A, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_d_out_A))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: d_out_A
				{
					// bitslice(31, 0)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_0_262080_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(63, 32)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_1_262081_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(95, 64)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_2_262082_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(127, 96)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_3_262083_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(159, 128)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_4_262084_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(191, 160)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_5_262085_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(223, 192)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_6_262086_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(255, 224)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_7_262087_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(287, 256)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_8_262088_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(319, 288)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_9_262089_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(351, 320)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_10_262090_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(383, 352)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_11_262091_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(415, 384)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_12_262092_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(447, 416)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_13_262093_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(479, 448)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_14_262094_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(511, 480)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_15_262095_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(543, 512)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_16_262096_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(575, 544)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_17_262097_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(607, 576)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_18_262098_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(639, 608)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_19_262099_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(671, 640)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_20_262100_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(703, 672)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_21_262101_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(735, 704)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_22_262102_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(767, 736)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_23_262103_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(799, 768)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_24_262104_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(831, 800)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_25_262105_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(863, 832)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_26_262106_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(895, 864)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_27_262107_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(927, 896)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_28_262108_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(959, 928)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_29_262109_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(991, 960)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_30_262110_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1023, 992)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_31_262111_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1055, 1024)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_32_262112_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1087, 1056)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_33_262113_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1119, 1088)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_34_262114_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1151, 1120)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_35_262115_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1183, 1152)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_36_262116_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1215, 1184)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_37_262117_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1247, 1216)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_38_262118_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1279, 1248)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_39_262119_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1311, 1280)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_40_262120_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1343, 1312)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_41_262121_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1375, 1344)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_42_262122_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1407, 1376)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_43_262123_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1439, 1408)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_44_262124_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1471, 1440)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_45_262125_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1503, 1472)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_46_262126_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1535, 1504)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_47_262127_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1567, 1536)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_48_262128_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1599, 1568)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_49_262129_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1631, 1600)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_50_262130_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1663, 1632)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_51_262131_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1695, 1664)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_52_262132_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1727, 1696)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_53_262133_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1759, 1728)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_54_262134_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1791, 1760)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_55_262135_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1823, 1792)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_56_262136_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1855, 1824)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_57_262137_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1887, 1856)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_58_262138_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1919, 1888)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_59_262139_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1951, 1920)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_60_262140_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1983, 1952)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_61_262141_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(2015, 1984)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_62_262142_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(2047, 2016)
					// {
						// celement: d_out.A(31, 0)
						// {
							sc_lv<32>* d_out_A_lv0_63_262143_64 = new sc_lv<32>[4096];
						// }
					// }

					// bitslice(31, 0)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (0) => (262080) @ (64)
							for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_0_262080_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(31, 0));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(63, 32)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (1) => (262081) @ (64)
							for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_1_262081_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(63, 32));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(95, 64)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (2) => (262082) @ (64)
							for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_2_262082_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(95, 64));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(127, 96)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (3) => (262083) @ (64)
							for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_3_262083_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(127, 96));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(159, 128)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (4) => (262084) @ (64)
							for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_4_262084_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(159, 128));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(191, 160)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (5) => (262085) @ (64)
							for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_5_262085_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(191, 160));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(223, 192)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (6) => (262086) @ (64)
							for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_6_262086_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(223, 192));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(255, 224)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (7) => (262087) @ (64)
							for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_7_262087_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(255, 224));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(287, 256)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (8) => (262088) @ (64)
							for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_8_262088_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(287, 256));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(319, 288)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (9) => (262089) @ (64)
							for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_9_262089_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(319, 288));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(351, 320)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (10) => (262090) @ (64)
							for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_10_262090_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(351, 320));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(383, 352)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (11) => (262091) @ (64)
							for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_11_262091_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(383, 352));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(415, 384)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (12) => (262092) @ (64)
							for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_12_262092_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(415, 384));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(447, 416)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (13) => (262093) @ (64)
							for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_13_262093_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(447, 416));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(479, 448)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (14) => (262094) @ (64)
							for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_14_262094_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(479, 448));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(511, 480)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (15) => (262095) @ (64)
							for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_15_262095_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(511, 480));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(543, 512)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (16) => (262096) @ (64)
							for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_16_262096_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(543, 512));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(575, 544)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (17) => (262097) @ (64)
							for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_17_262097_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(575, 544));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(607, 576)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (18) => (262098) @ (64)
							for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_18_262098_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(607, 576));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(639, 608)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (19) => (262099) @ (64)
							for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_19_262099_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(639, 608));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(671, 640)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (20) => (262100) @ (64)
							for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_20_262100_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(671, 640));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(703, 672)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (21) => (262101) @ (64)
							for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_21_262101_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(703, 672));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(735, 704)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (22) => (262102) @ (64)
							for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_22_262102_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(735, 704));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(767, 736)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (23) => (262103) @ (64)
							for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_23_262103_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(767, 736));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(799, 768)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (24) => (262104) @ (64)
							for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_24_262104_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(799, 768));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(831, 800)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (25) => (262105) @ (64)
							for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_25_262105_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(831, 800));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(863, 832)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (26) => (262106) @ (64)
							for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_26_262106_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(863, 832));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(895, 864)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (27) => (262107) @ (64)
							for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_27_262107_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(895, 864));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(927, 896)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (28) => (262108) @ (64)
							for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_28_262108_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(927, 896));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(959, 928)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (29) => (262109) @ (64)
							for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_29_262109_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(959, 928));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(991, 960)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (30) => (262110) @ (64)
							for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_30_262110_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(991, 960));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1023, 992)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (31) => (262111) @ (64)
							for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_31_262111_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1023, 992));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1055, 1024)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (32) => (262112) @ (64)
							for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_32_262112_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1055, 1024));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1087, 1056)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (33) => (262113) @ (64)
							for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_33_262113_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1087, 1056));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1119, 1088)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (34) => (262114) @ (64)
							for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_34_262114_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1119, 1088));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1151, 1120)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (35) => (262115) @ (64)
							for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_35_262115_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1151, 1120));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1183, 1152)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (36) => (262116) @ (64)
							for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_36_262116_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1183, 1152));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1215, 1184)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (37) => (262117) @ (64)
							for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_37_262117_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1215, 1184));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1247, 1216)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (38) => (262118) @ (64)
							for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_38_262118_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1247, 1216));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1279, 1248)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (39) => (262119) @ (64)
							for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_39_262119_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1279, 1248));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1311, 1280)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (40) => (262120) @ (64)
							for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_40_262120_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1311, 1280));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1343, 1312)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (41) => (262121) @ (64)
							for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_41_262121_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1343, 1312));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1375, 1344)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (42) => (262122) @ (64)
							for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_42_262122_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1375, 1344));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1407, 1376)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (43) => (262123) @ (64)
							for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_43_262123_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1407, 1376));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1439, 1408)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (44) => (262124) @ (64)
							for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_44_262124_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1439, 1408));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1471, 1440)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (45) => (262125) @ (64)
							for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_45_262125_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1471, 1440));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1503, 1472)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (46) => (262126) @ (64)
							for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_46_262126_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1503, 1472));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1535, 1504)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (47) => (262127) @ (64)
							for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_47_262127_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1535, 1504));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1567, 1536)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (48) => (262128) @ (64)
							for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_48_262128_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1567, 1536));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1599, 1568)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (49) => (262129) @ (64)
							for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_49_262129_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1599, 1568));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1631, 1600)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (50) => (262130) @ (64)
							for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_50_262130_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1631, 1600));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1663, 1632)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (51) => (262131) @ (64)
							for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_51_262131_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1663, 1632));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1695, 1664)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (52) => (262132) @ (64)
							for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_52_262132_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1695, 1664));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1727, 1696)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (53) => (262133) @ (64)
							for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_53_262133_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1727, 1696));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1759, 1728)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (54) => (262134) @ (64)
							for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_54_262134_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1759, 1728));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1791, 1760)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (55) => (262135) @ (64)
							for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_55_262135_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1791, 1760));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1823, 1792)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (56) => (262136) @ (64)
							for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_56_262136_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1823, 1792));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1855, 1824)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (57) => (262137) @ (64)
							for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_57_262137_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1855, 1824));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1887, 1856)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (58) => (262138) @ (64)
							for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_58_262138_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1887, 1856));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1919, 1888)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (59) => (262139) @ (64)
							for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_59_262139_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1919, 1888));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1951, 1920)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (60) => (262140) @ (64)
							for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_60_262140_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1951, 1920));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1983, 1952)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (61) => (262141) @ (64)
							for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_61_262141_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(1983, 1952));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(2015, 1984)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (62) => (262142) @ (64)
							for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_62_262142_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(2015, 1984));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(2047, 2016)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (63) => (262143) @ (64)
							for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
							{
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_A_lv0_63_262143_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_A_pc_buffer[hls_map_index].range(2047, 2016));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(31, 0)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (0) => (262080) @ (64)
							for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_0_262080_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_0_262080_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(63, 32)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (1) => (262081) @ (64)
							for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_1_262081_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_1_262081_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(95, 64)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (2) => (262082) @ (64)
							for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_2_262082_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_2_262082_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(127, 96)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (3) => (262083) @ (64)
							for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_3_262083_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_3_262083_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(159, 128)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (4) => (262084) @ (64)
							for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_4_262084_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_4_262084_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(191, 160)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (5) => (262085) @ (64)
							for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_5_262085_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_5_262085_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(223, 192)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (6) => (262086) @ (64)
							for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_6_262086_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_6_262086_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(255, 224)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (7) => (262087) @ (64)
							for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_7_262087_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_7_262087_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(287, 256)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (8) => (262088) @ (64)
							for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_8_262088_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_8_262088_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(319, 288)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (9) => (262089) @ (64)
							for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_9_262089_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_9_262089_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(351, 320)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (10) => (262090) @ (64)
							for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_10_262090_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_10_262090_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(383, 352)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (11) => (262091) @ (64)
							for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_11_262091_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_11_262091_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(415, 384)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (12) => (262092) @ (64)
							for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_12_262092_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_12_262092_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(447, 416)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (13) => (262093) @ (64)
							for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_13_262093_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_13_262093_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(479, 448)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (14) => (262094) @ (64)
							for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_14_262094_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_14_262094_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(511, 480)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (15) => (262095) @ (64)
							for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_15_262095_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_15_262095_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(543, 512)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (16) => (262096) @ (64)
							for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_16_262096_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_16_262096_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(575, 544)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (17) => (262097) @ (64)
							for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_17_262097_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_17_262097_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(607, 576)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (18) => (262098) @ (64)
							for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_18_262098_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_18_262098_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(639, 608)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (19) => (262099) @ (64)
							for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_19_262099_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_19_262099_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(671, 640)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (20) => (262100) @ (64)
							for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_20_262100_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_20_262100_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(703, 672)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (21) => (262101) @ (64)
							for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_21_262101_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_21_262101_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(735, 704)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (22) => (262102) @ (64)
							for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_22_262102_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_22_262102_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(767, 736)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (23) => (262103) @ (64)
							for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_23_262103_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_23_262103_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(799, 768)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (24) => (262104) @ (64)
							for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_24_262104_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_24_262104_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(831, 800)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (25) => (262105) @ (64)
							for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_25_262105_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_25_262105_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(863, 832)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (26) => (262106) @ (64)
							for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_26_262106_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_26_262106_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(895, 864)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (27) => (262107) @ (64)
							for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_27_262107_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_27_262107_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(927, 896)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (28) => (262108) @ (64)
							for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_28_262108_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_28_262108_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(959, 928)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (29) => (262109) @ (64)
							for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_29_262109_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_29_262109_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(991, 960)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (30) => (262110) @ (64)
							for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_30_262110_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_30_262110_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1023, 992)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (31) => (262111) @ (64)
							for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_31_262111_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_31_262111_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1055, 1024)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (32) => (262112) @ (64)
							for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_32_262112_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_32_262112_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1087, 1056)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (33) => (262113) @ (64)
							for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_33_262113_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_33_262113_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1119, 1088)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (34) => (262114) @ (64)
							for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_34_262114_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_34_262114_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1151, 1120)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (35) => (262115) @ (64)
							for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_35_262115_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_35_262115_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1183, 1152)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (36) => (262116) @ (64)
							for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_36_262116_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_36_262116_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1215, 1184)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (37) => (262117) @ (64)
							for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_37_262117_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_37_262117_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1247, 1216)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (38) => (262118) @ (64)
							for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_38_262118_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_38_262118_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1279, 1248)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (39) => (262119) @ (64)
							for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_39_262119_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_39_262119_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1311, 1280)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (40) => (262120) @ (64)
							for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_40_262120_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_40_262120_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1343, 1312)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (41) => (262121) @ (64)
							for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_41_262121_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_41_262121_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1375, 1344)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (42) => (262122) @ (64)
							for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_42_262122_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_42_262122_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1407, 1376)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (43) => (262123) @ (64)
							for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_43_262123_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_43_262123_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1439, 1408)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (44) => (262124) @ (64)
							for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_44_262124_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_44_262124_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1471, 1440)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (45) => (262125) @ (64)
							for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_45_262125_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_45_262125_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1503, 1472)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (46) => (262126) @ (64)
							for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_46_262126_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_46_262126_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1535, 1504)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (47) => (262127) @ (64)
							for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_47_262127_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_47_262127_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1567, 1536)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (48) => (262128) @ (64)
							for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_48_262128_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_48_262128_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1599, 1568)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (49) => (262129) @ (64)
							for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_49_262129_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_49_262129_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1631, 1600)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (50) => (262130) @ (64)
							for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_50_262130_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_50_262130_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1663, 1632)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (51) => (262131) @ (64)
							for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_51_262131_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_51_262131_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1695, 1664)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (52) => (262132) @ (64)
							for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_52_262132_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_52_262132_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1727, 1696)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (53) => (262133) @ (64)
							for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_53_262133_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_53_262133_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1759, 1728)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (54) => (262134) @ (64)
							for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_54_262134_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_54_262134_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1791, 1760)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (55) => (262135) @ (64)
							for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_55_262135_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_55_262135_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1823, 1792)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (56) => (262136) @ (64)
							for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_56_262136_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_56_262136_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1855, 1824)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (57) => (262137) @ (64)
							for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_57_262137_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_57_262137_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1887, 1856)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (58) => (262138) @ (64)
							for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_58_262138_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_58_262138_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1919, 1888)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (59) => (262139) @ (64)
							for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_59_262139_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_59_262139_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1951, 1920)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (60) => (262140) @ (64)
							for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_60_262140_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_60_262140_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1983, 1952)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (61) => (262141) @ (64)
							for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_61_262141_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_61_262141_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(2015, 1984)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (62) => (262142) @ (64)
							for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_62_262142_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_62_262142_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(2047, 2016)
					{
						int hls_map_index = 0;
						// celement: d_out.A(31, 0)
						{
							// carray: (63) => (262143) @ (64)
							for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->A[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->A[0]
								// output_left_conversion : d_out->A[i_0]
								// output_type_conversion : (d_out_A_lv0_63_262143_64[hls_map_index]).to_uint64()
								if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->A[i_0] = (d_out_A_lv0_63_262143_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] d_out_A_pc_buffer;
		}

		// output port post check: "d_out_B"
		aesl_fh.read(AUTOTB_TVOUT_PC_d_out_B, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_d_out_B, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_d_out_B, AESL_token); // data

			sc_bv<2048> *d_out_B_pc_buffer = new sc_bv<2048>[4096];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'd_out_B', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'd_out_B', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					d_out_B_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_d_out_B, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_d_out_B))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: d_out_B
				{
					// bitslice(31, 0)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_0_262080_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(63, 32)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_1_262081_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(95, 64)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_2_262082_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(127, 96)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_3_262083_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(159, 128)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_4_262084_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(191, 160)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_5_262085_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(223, 192)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_6_262086_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(255, 224)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_7_262087_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(287, 256)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_8_262088_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(319, 288)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_9_262089_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(351, 320)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_10_262090_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(383, 352)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_11_262091_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(415, 384)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_12_262092_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(447, 416)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_13_262093_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(479, 448)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_14_262094_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(511, 480)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_15_262095_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(543, 512)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_16_262096_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(575, 544)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_17_262097_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(607, 576)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_18_262098_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(639, 608)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_19_262099_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(671, 640)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_20_262100_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(703, 672)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_21_262101_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(735, 704)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_22_262102_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(767, 736)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_23_262103_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(799, 768)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_24_262104_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(831, 800)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_25_262105_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(863, 832)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_26_262106_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(895, 864)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_27_262107_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(927, 896)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_28_262108_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(959, 928)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_29_262109_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(991, 960)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_30_262110_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1023, 992)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_31_262111_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1055, 1024)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_32_262112_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1087, 1056)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_33_262113_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1119, 1088)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_34_262114_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1151, 1120)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_35_262115_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1183, 1152)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_36_262116_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1215, 1184)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_37_262117_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1247, 1216)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_38_262118_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1279, 1248)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_39_262119_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1311, 1280)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_40_262120_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1343, 1312)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_41_262121_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1375, 1344)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_42_262122_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1407, 1376)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_43_262123_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1439, 1408)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_44_262124_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1471, 1440)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_45_262125_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1503, 1472)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_46_262126_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1535, 1504)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_47_262127_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1567, 1536)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_48_262128_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1599, 1568)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_49_262129_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1631, 1600)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_50_262130_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1663, 1632)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_51_262131_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1695, 1664)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_52_262132_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1727, 1696)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_53_262133_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1759, 1728)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_54_262134_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1791, 1760)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_55_262135_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1823, 1792)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_56_262136_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1855, 1824)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_57_262137_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1887, 1856)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_58_262138_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1919, 1888)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_59_262139_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1951, 1920)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_60_262140_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(1983, 1952)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_61_262141_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(2015, 1984)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_62_262142_64 = new sc_lv<32>[4096];
						// }
					// }
					// bitslice(2047, 2016)
					// {
						// celement: d_out.B(31, 0)
						// {
							sc_lv<32>* d_out_B_lv0_63_262143_64 = new sc_lv<32>[4096];
						// }
					// }

					// bitslice(31, 0)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (0) => (262080) @ (64)
							for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_0_262080_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(31, 0));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(63, 32)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (1) => (262081) @ (64)
							for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_1_262081_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(63, 32));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(95, 64)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (2) => (262082) @ (64)
							for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_2_262082_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(95, 64));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(127, 96)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (3) => (262083) @ (64)
							for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_3_262083_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(127, 96));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(159, 128)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (4) => (262084) @ (64)
							for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_4_262084_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(159, 128));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(191, 160)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (5) => (262085) @ (64)
							for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_5_262085_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(191, 160));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(223, 192)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (6) => (262086) @ (64)
							for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_6_262086_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(223, 192));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(255, 224)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (7) => (262087) @ (64)
							for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_7_262087_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(255, 224));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(287, 256)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (8) => (262088) @ (64)
							for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_8_262088_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(287, 256));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(319, 288)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (9) => (262089) @ (64)
							for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_9_262089_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(319, 288));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(351, 320)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (10) => (262090) @ (64)
							for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_10_262090_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(351, 320));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(383, 352)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (11) => (262091) @ (64)
							for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_11_262091_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(383, 352));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(415, 384)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (12) => (262092) @ (64)
							for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_12_262092_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(415, 384));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(447, 416)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (13) => (262093) @ (64)
							for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_13_262093_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(447, 416));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(479, 448)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (14) => (262094) @ (64)
							for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_14_262094_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(479, 448));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(511, 480)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (15) => (262095) @ (64)
							for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_15_262095_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(511, 480));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(543, 512)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (16) => (262096) @ (64)
							for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_16_262096_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(543, 512));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(575, 544)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (17) => (262097) @ (64)
							for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_17_262097_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(575, 544));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(607, 576)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (18) => (262098) @ (64)
							for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_18_262098_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(607, 576));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(639, 608)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (19) => (262099) @ (64)
							for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_19_262099_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(639, 608));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(671, 640)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (20) => (262100) @ (64)
							for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_20_262100_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(671, 640));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(703, 672)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (21) => (262101) @ (64)
							for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_21_262101_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(703, 672));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(735, 704)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (22) => (262102) @ (64)
							for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_22_262102_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(735, 704));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(767, 736)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (23) => (262103) @ (64)
							for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_23_262103_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(767, 736));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(799, 768)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (24) => (262104) @ (64)
							for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_24_262104_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(799, 768));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(831, 800)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (25) => (262105) @ (64)
							for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_25_262105_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(831, 800));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(863, 832)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (26) => (262106) @ (64)
							for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_26_262106_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(863, 832));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(895, 864)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (27) => (262107) @ (64)
							for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_27_262107_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(895, 864));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(927, 896)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (28) => (262108) @ (64)
							for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_28_262108_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(927, 896));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(959, 928)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (29) => (262109) @ (64)
							for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_29_262109_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(959, 928));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(991, 960)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (30) => (262110) @ (64)
							for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_30_262110_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(991, 960));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1023, 992)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (31) => (262111) @ (64)
							for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_31_262111_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1023, 992));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1055, 1024)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (32) => (262112) @ (64)
							for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_32_262112_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1055, 1024));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1087, 1056)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (33) => (262113) @ (64)
							for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_33_262113_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1087, 1056));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1119, 1088)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (34) => (262114) @ (64)
							for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_34_262114_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1119, 1088));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1151, 1120)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (35) => (262115) @ (64)
							for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_35_262115_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1151, 1120));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1183, 1152)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (36) => (262116) @ (64)
							for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_36_262116_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1183, 1152));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1215, 1184)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (37) => (262117) @ (64)
							for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_37_262117_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1215, 1184));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1247, 1216)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (38) => (262118) @ (64)
							for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_38_262118_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1247, 1216));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1279, 1248)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (39) => (262119) @ (64)
							for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_39_262119_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1279, 1248));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1311, 1280)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (40) => (262120) @ (64)
							for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_40_262120_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1311, 1280));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1343, 1312)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (41) => (262121) @ (64)
							for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_41_262121_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1343, 1312));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1375, 1344)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (42) => (262122) @ (64)
							for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_42_262122_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1375, 1344));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1407, 1376)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (43) => (262123) @ (64)
							for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_43_262123_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1407, 1376));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1439, 1408)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (44) => (262124) @ (64)
							for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_44_262124_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1439, 1408));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1471, 1440)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (45) => (262125) @ (64)
							for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_45_262125_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1471, 1440));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1503, 1472)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (46) => (262126) @ (64)
							for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_46_262126_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1503, 1472));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1535, 1504)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (47) => (262127) @ (64)
							for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_47_262127_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1535, 1504));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1567, 1536)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (48) => (262128) @ (64)
							for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_48_262128_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1567, 1536));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1599, 1568)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (49) => (262129) @ (64)
							for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_49_262129_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1599, 1568));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1631, 1600)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (50) => (262130) @ (64)
							for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_50_262130_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1631, 1600));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1663, 1632)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (51) => (262131) @ (64)
							for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_51_262131_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1663, 1632));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1695, 1664)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (52) => (262132) @ (64)
							for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_52_262132_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1695, 1664));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1727, 1696)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (53) => (262133) @ (64)
							for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_53_262133_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1727, 1696));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1759, 1728)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (54) => (262134) @ (64)
							for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_54_262134_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1759, 1728));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1791, 1760)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (55) => (262135) @ (64)
							for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_55_262135_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1791, 1760));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1823, 1792)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (56) => (262136) @ (64)
							for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_56_262136_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1823, 1792));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1855, 1824)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (57) => (262137) @ (64)
							for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_57_262137_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1855, 1824));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1887, 1856)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (58) => (262138) @ (64)
							for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_58_262138_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1887, 1856));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1919, 1888)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (59) => (262139) @ (64)
							for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_59_262139_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1919, 1888));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1951, 1920)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (60) => (262140) @ (64)
							for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_60_262140_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1951, 1920));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1983, 1952)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (61) => (262141) @ (64)
							for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_61_262141_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(1983, 1952));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(2015, 1984)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (62) => (262142) @ (64)
							for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_62_262142_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(2015, 1984));
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(2047, 2016)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (63) => (262143) @ (64)
							for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
							{
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out_B_lv0_63_262143_64[hls_map_index].range(31, 0) = sc_bv<32>(d_out_B_pc_buffer[hls_map_index].range(2047, 2016));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(31, 0)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (0) => (262080) @ (64)
							for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_0_262080_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_0_262080_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(63, 32)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (1) => (262081) @ (64)
							for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_1_262081_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_1_262081_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(95, 64)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (2) => (262082) @ (64)
							for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_2_262082_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_2_262082_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(127, 96)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (3) => (262083) @ (64)
							for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_3_262083_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_3_262083_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(159, 128)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (4) => (262084) @ (64)
							for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_4_262084_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_4_262084_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(191, 160)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (5) => (262085) @ (64)
							for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_5_262085_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_5_262085_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(223, 192)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (6) => (262086) @ (64)
							for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_6_262086_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_6_262086_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(255, 224)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (7) => (262087) @ (64)
							for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_7_262087_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_7_262087_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(287, 256)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (8) => (262088) @ (64)
							for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_8_262088_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_8_262088_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(319, 288)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (9) => (262089) @ (64)
							for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_9_262089_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_9_262089_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(351, 320)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (10) => (262090) @ (64)
							for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_10_262090_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_10_262090_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(383, 352)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (11) => (262091) @ (64)
							for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_11_262091_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_11_262091_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(415, 384)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (12) => (262092) @ (64)
							for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_12_262092_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_12_262092_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(447, 416)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (13) => (262093) @ (64)
							for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_13_262093_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_13_262093_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(479, 448)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (14) => (262094) @ (64)
							for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_14_262094_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_14_262094_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(511, 480)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (15) => (262095) @ (64)
							for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_15_262095_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_15_262095_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(543, 512)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (16) => (262096) @ (64)
							for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_16_262096_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_16_262096_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(575, 544)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (17) => (262097) @ (64)
							for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_17_262097_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_17_262097_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(607, 576)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (18) => (262098) @ (64)
							for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_18_262098_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_18_262098_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(639, 608)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (19) => (262099) @ (64)
							for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_19_262099_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_19_262099_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(671, 640)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (20) => (262100) @ (64)
							for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_20_262100_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_20_262100_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(703, 672)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (21) => (262101) @ (64)
							for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_21_262101_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_21_262101_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(735, 704)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (22) => (262102) @ (64)
							for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_22_262102_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_22_262102_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(767, 736)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (23) => (262103) @ (64)
							for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_23_262103_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_23_262103_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(799, 768)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (24) => (262104) @ (64)
							for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_24_262104_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_24_262104_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(831, 800)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (25) => (262105) @ (64)
							for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_25_262105_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_25_262105_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(863, 832)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (26) => (262106) @ (64)
							for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_26_262106_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_26_262106_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(895, 864)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (27) => (262107) @ (64)
							for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_27_262107_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_27_262107_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(927, 896)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (28) => (262108) @ (64)
							for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_28_262108_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_28_262108_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(959, 928)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (29) => (262109) @ (64)
							for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_29_262109_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_29_262109_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(991, 960)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (30) => (262110) @ (64)
							for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_30_262110_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_30_262110_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1023, 992)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (31) => (262111) @ (64)
							for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_31_262111_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_31_262111_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1055, 1024)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (32) => (262112) @ (64)
							for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_32_262112_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_32_262112_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1087, 1056)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (33) => (262113) @ (64)
							for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_33_262113_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_33_262113_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1119, 1088)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (34) => (262114) @ (64)
							for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_34_262114_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_34_262114_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1151, 1120)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (35) => (262115) @ (64)
							for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_35_262115_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_35_262115_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1183, 1152)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (36) => (262116) @ (64)
							for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_36_262116_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_36_262116_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1215, 1184)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (37) => (262117) @ (64)
							for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_37_262117_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_37_262117_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1247, 1216)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (38) => (262118) @ (64)
							for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_38_262118_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_38_262118_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1279, 1248)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (39) => (262119) @ (64)
							for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_39_262119_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_39_262119_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1311, 1280)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (40) => (262120) @ (64)
							for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_40_262120_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_40_262120_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1343, 1312)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (41) => (262121) @ (64)
							for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_41_262121_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_41_262121_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1375, 1344)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (42) => (262122) @ (64)
							for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_42_262122_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_42_262122_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1407, 1376)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (43) => (262123) @ (64)
							for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_43_262123_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_43_262123_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1439, 1408)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (44) => (262124) @ (64)
							for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_44_262124_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_44_262124_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1471, 1440)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (45) => (262125) @ (64)
							for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_45_262125_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_45_262125_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1503, 1472)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (46) => (262126) @ (64)
							for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_46_262126_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_46_262126_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1535, 1504)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (47) => (262127) @ (64)
							for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_47_262127_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_47_262127_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1567, 1536)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (48) => (262128) @ (64)
							for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_48_262128_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_48_262128_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1599, 1568)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (49) => (262129) @ (64)
							for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_49_262129_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_49_262129_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1631, 1600)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (50) => (262130) @ (64)
							for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_50_262130_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_50_262130_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1663, 1632)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (51) => (262131) @ (64)
							for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_51_262131_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_51_262131_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1695, 1664)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (52) => (262132) @ (64)
							for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_52_262132_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_52_262132_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1727, 1696)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (53) => (262133) @ (64)
							for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_53_262133_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_53_262133_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1759, 1728)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (54) => (262134) @ (64)
							for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_54_262134_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_54_262134_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1791, 1760)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (55) => (262135) @ (64)
							for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_55_262135_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_55_262135_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1823, 1792)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (56) => (262136) @ (64)
							for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_56_262136_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_56_262136_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1855, 1824)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (57) => (262137) @ (64)
							for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_57_262137_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_57_262137_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1887, 1856)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (58) => (262138) @ (64)
							for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_58_262138_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_58_262138_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1919, 1888)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (59) => (262139) @ (64)
							for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_59_262139_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_59_262139_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1951, 1920)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (60) => (262140) @ (64)
							for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_60_262140_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_60_262140_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(1983, 1952)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (61) => (262141) @ (64)
							for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_61_262141_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_61_262141_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(2015, 1984)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (62) => (262142) @ (64)
							for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_62_262142_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_62_262142_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
					// bitslice(2047, 2016)
					{
						int hls_map_index = 0;
						// celement: d_out.B(31, 0)
						{
							// carray: (63) => (262143) @ (64)
							for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
							{
								// sub                    : i_0
								// ori_name               : d_out->B[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : d_out->B[0]
								// output_left_conversion : d_out->B[i_0]
								// output_type_conversion : (d_out_B_lv0_63_262143_64[hls_map_index]).to_uint64()
								if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
								{
									d_out->B[i_0] = (d_out_B_lv0_63_262143_64[hls_map_index]).to_uint64();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] d_out_B_pc_buffer;
		}

		AESL_transaction_pc++;
	}
	else
	{
		CodeState = ENTER_WRAPC;
		static unsigned AESL_transaction;

		static AESL_FILE_HANDLER aesl_fh;

		// "d_in_A"
		char* tvin_d_in_A = new char[517];
		aesl_fh.touch(AUTOTB_TVIN_d_in_A);

		// "d_in_B"
		char* tvin_d_in_B = new char[517];
		aesl_fh.touch(AUTOTB_TVIN_d_in_B);

		// "d_out_A"
		char* tvin_d_out_A = new char[517];
		aesl_fh.touch(AUTOTB_TVIN_d_out_A);
		char* tvout_d_out_A = new char[517];
		aesl_fh.touch(AUTOTB_TVOUT_d_out_A);

		// "d_out_B"
		char* tvin_d_out_B = new char[517];
		aesl_fh.touch(AUTOTB_TVIN_d_out_B);
		char* tvout_d_out_B = new char[517];
		aesl_fh.touch(AUTOTB_TVOUT_d_out_B);

		CodeState = DUMP_INPUTS;
		static INTER_TCL_FILE tcl_file(INTER_TCL);
		int leading_zero;

		// [[transaction]]
		sprintf(tvin_d_in_A, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_d_in_A, tvin_d_in_A);

		sc_bv<2048>* d_in_A_tvin_wrapc_buffer = new sc_bv<2048>[4096];

		// RTL Name: d_in_A
		{
			// bitslice(31, 0)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (0) => (262080) @ (64)
					for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(31, 0) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(63, 32)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (1) => (262081) @ (64)
					for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(63, 32) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(95, 64)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (2) => (262082) @ (64)
					for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(95, 64) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(127, 96)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (3) => (262083) @ (64)
					for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(127, 96) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(159, 128)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (4) => (262084) @ (64)
					for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(159, 128) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(191, 160)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (5) => (262085) @ (64)
					for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(191, 160) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(223, 192)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (6) => (262086) @ (64)
					for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(223, 192) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(255, 224)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (7) => (262087) @ (64)
					for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(255, 224) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(287, 256)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (8) => (262088) @ (64)
					for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(287, 256) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(319, 288)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (9) => (262089) @ (64)
					for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(319, 288) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(351, 320)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (10) => (262090) @ (64)
					for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(351, 320) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(383, 352)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (11) => (262091) @ (64)
					for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(383, 352) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(415, 384)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (12) => (262092) @ (64)
					for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(415, 384) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(447, 416)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (13) => (262093) @ (64)
					for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(447, 416) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(479, 448)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (14) => (262094) @ (64)
					for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(479, 448) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(511, 480)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (15) => (262095) @ (64)
					for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(511, 480) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(543, 512)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (16) => (262096) @ (64)
					for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(543, 512) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(575, 544)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (17) => (262097) @ (64)
					for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(575, 544) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(607, 576)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (18) => (262098) @ (64)
					for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(607, 576) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(639, 608)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (19) => (262099) @ (64)
					for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(639, 608) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(671, 640)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (20) => (262100) @ (64)
					for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(671, 640) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(703, 672)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (21) => (262101) @ (64)
					for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(703, 672) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(735, 704)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (22) => (262102) @ (64)
					for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(735, 704) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(767, 736)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (23) => (262103) @ (64)
					for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(767, 736) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(799, 768)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (24) => (262104) @ (64)
					for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(799, 768) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(831, 800)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (25) => (262105) @ (64)
					for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(831, 800) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(863, 832)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (26) => (262106) @ (64)
					for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(863, 832) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(895, 864)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (27) => (262107) @ (64)
					for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(895, 864) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(927, 896)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (28) => (262108) @ (64)
					for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(927, 896) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(959, 928)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (29) => (262109) @ (64)
					for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(959, 928) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(991, 960)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (30) => (262110) @ (64)
					for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(991, 960) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1023, 992)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (31) => (262111) @ (64)
					for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1023, 992) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1055, 1024)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (32) => (262112) @ (64)
					for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1055, 1024) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1087, 1056)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (33) => (262113) @ (64)
					for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1087, 1056) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1119, 1088)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (34) => (262114) @ (64)
					for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1119, 1088) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1151, 1120)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (35) => (262115) @ (64)
					for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1151, 1120) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1183, 1152)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (36) => (262116) @ (64)
					for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1183, 1152) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1215, 1184)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (37) => (262117) @ (64)
					for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1215, 1184) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1247, 1216)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (38) => (262118) @ (64)
					for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1247, 1216) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1279, 1248)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (39) => (262119) @ (64)
					for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1279, 1248) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1311, 1280)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (40) => (262120) @ (64)
					for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1311, 1280) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1343, 1312)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (41) => (262121) @ (64)
					for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1343, 1312) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1375, 1344)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (42) => (262122) @ (64)
					for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1375, 1344) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1407, 1376)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (43) => (262123) @ (64)
					for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1407, 1376) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1439, 1408)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (44) => (262124) @ (64)
					for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1439, 1408) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1471, 1440)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (45) => (262125) @ (64)
					for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1471, 1440) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1503, 1472)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (46) => (262126) @ (64)
					for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1503, 1472) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1535, 1504)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (47) => (262127) @ (64)
					for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1535, 1504) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1567, 1536)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (48) => (262128) @ (64)
					for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1567, 1536) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1599, 1568)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (49) => (262129) @ (64)
					for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1599, 1568) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1631, 1600)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (50) => (262130) @ (64)
					for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1631, 1600) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1663, 1632)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (51) => (262131) @ (64)
					for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1663, 1632) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1695, 1664)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (52) => (262132) @ (64)
					for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1695, 1664) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1727, 1696)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (53) => (262133) @ (64)
					for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1727, 1696) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1759, 1728)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (54) => (262134) @ (64)
					for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1759, 1728) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1791, 1760)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (55) => (262135) @ (64)
					for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1791, 1760) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1823, 1792)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (56) => (262136) @ (64)
					for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1823, 1792) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1855, 1824)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (57) => (262137) @ (64)
					for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1855, 1824) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1887, 1856)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (58) => (262138) @ (64)
					for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1887, 1856) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1919, 1888)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (59) => (262139) @ (64)
					for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1919, 1888) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1951, 1920)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (60) => (262140) @ (64)
					for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1951, 1920) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1983, 1952)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (61) => (262141) @ (64)
					for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(1983, 1952) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2015, 1984)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (62) => (262142) @ (64)
					for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(2015, 1984) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2047, 2016)
			{
				int hls_map_index = 0;
				// celement: d_in.A(31, 0)
				{
					// carray: (63) => (262143) @ (64)
					for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.A[0]
						// regulate_c_name       : d_in_A
						// input_type_conversion : d_in.A[i_0]
						if (&(d_in.A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_A_tmp_mem;
							d_in_A_tmp_mem = d_in.A[i_0];
							d_in_A_tvin_wrapc_buffer[hls_map_index].range(2047, 2016) = d_in_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 4096; i++)
		{
			sprintf(tvin_d_in_A, "%s\n", (d_in_A_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_d_in_A, tvin_d_in_A);
		}

		tcl_file.set_num(4096, &tcl_file.d_in_A_depth);
		sprintf(tvin_d_in_A, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_d_in_A, tvin_d_in_A);

		// release memory allocation
		delete [] d_in_A_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_d_in_B, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_d_in_B, tvin_d_in_B);

		sc_bv<2048>* d_in_B_tvin_wrapc_buffer = new sc_bv<2048>[4096];

		// RTL Name: d_in_B
		{
			// bitslice(31, 0)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (0) => (262080) @ (64)
					for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(31, 0) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(63, 32)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (1) => (262081) @ (64)
					for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(63, 32) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(95, 64)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (2) => (262082) @ (64)
					for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(95, 64) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(127, 96)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (3) => (262083) @ (64)
					for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(127, 96) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(159, 128)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (4) => (262084) @ (64)
					for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(159, 128) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(191, 160)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (5) => (262085) @ (64)
					for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(191, 160) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(223, 192)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (6) => (262086) @ (64)
					for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(223, 192) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(255, 224)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (7) => (262087) @ (64)
					for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(255, 224) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(287, 256)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (8) => (262088) @ (64)
					for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(287, 256) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(319, 288)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (9) => (262089) @ (64)
					for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(319, 288) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(351, 320)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (10) => (262090) @ (64)
					for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(351, 320) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(383, 352)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (11) => (262091) @ (64)
					for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(383, 352) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(415, 384)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (12) => (262092) @ (64)
					for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(415, 384) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(447, 416)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (13) => (262093) @ (64)
					for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(447, 416) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(479, 448)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (14) => (262094) @ (64)
					for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(479, 448) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(511, 480)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (15) => (262095) @ (64)
					for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(511, 480) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(543, 512)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (16) => (262096) @ (64)
					for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(543, 512) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(575, 544)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (17) => (262097) @ (64)
					for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(575, 544) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(607, 576)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (18) => (262098) @ (64)
					for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(607, 576) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(639, 608)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (19) => (262099) @ (64)
					for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(639, 608) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(671, 640)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (20) => (262100) @ (64)
					for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(671, 640) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(703, 672)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (21) => (262101) @ (64)
					for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(703, 672) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(735, 704)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (22) => (262102) @ (64)
					for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(735, 704) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(767, 736)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (23) => (262103) @ (64)
					for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(767, 736) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(799, 768)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (24) => (262104) @ (64)
					for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(799, 768) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(831, 800)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (25) => (262105) @ (64)
					for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(831, 800) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(863, 832)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (26) => (262106) @ (64)
					for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(863, 832) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(895, 864)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (27) => (262107) @ (64)
					for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(895, 864) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(927, 896)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (28) => (262108) @ (64)
					for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(927, 896) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(959, 928)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (29) => (262109) @ (64)
					for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(959, 928) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(991, 960)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (30) => (262110) @ (64)
					for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(991, 960) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1023, 992)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (31) => (262111) @ (64)
					for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1023, 992) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1055, 1024)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (32) => (262112) @ (64)
					for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1055, 1024) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1087, 1056)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (33) => (262113) @ (64)
					for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1087, 1056) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1119, 1088)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (34) => (262114) @ (64)
					for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1119, 1088) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1151, 1120)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (35) => (262115) @ (64)
					for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1151, 1120) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1183, 1152)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (36) => (262116) @ (64)
					for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1183, 1152) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1215, 1184)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (37) => (262117) @ (64)
					for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1215, 1184) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1247, 1216)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (38) => (262118) @ (64)
					for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1247, 1216) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1279, 1248)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (39) => (262119) @ (64)
					for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1279, 1248) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1311, 1280)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (40) => (262120) @ (64)
					for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1311, 1280) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1343, 1312)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (41) => (262121) @ (64)
					for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1343, 1312) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1375, 1344)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (42) => (262122) @ (64)
					for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1375, 1344) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1407, 1376)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (43) => (262123) @ (64)
					for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1407, 1376) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1439, 1408)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (44) => (262124) @ (64)
					for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1439, 1408) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1471, 1440)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (45) => (262125) @ (64)
					for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1471, 1440) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1503, 1472)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (46) => (262126) @ (64)
					for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1503, 1472) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1535, 1504)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (47) => (262127) @ (64)
					for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1535, 1504) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1567, 1536)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (48) => (262128) @ (64)
					for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1567, 1536) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1599, 1568)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (49) => (262129) @ (64)
					for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1599, 1568) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1631, 1600)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (50) => (262130) @ (64)
					for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1631, 1600) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1663, 1632)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (51) => (262131) @ (64)
					for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1663, 1632) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1695, 1664)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (52) => (262132) @ (64)
					for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1695, 1664) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1727, 1696)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (53) => (262133) @ (64)
					for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1727, 1696) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1759, 1728)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (54) => (262134) @ (64)
					for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1759, 1728) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1791, 1760)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (55) => (262135) @ (64)
					for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1791, 1760) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1823, 1792)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (56) => (262136) @ (64)
					for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1823, 1792) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1855, 1824)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (57) => (262137) @ (64)
					for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1855, 1824) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1887, 1856)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (58) => (262138) @ (64)
					for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1887, 1856) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1919, 1888)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (59) => (262139) @ (64)
					for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1919, 1888) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1951, 1920)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (60) => (262140) @ (64)
					for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1951, 1920) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1983, 1952)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (61) => (262141) @ (64)
					for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(1983, 1952) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2015, 1984)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (62) => (262142) @ (64)
					for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(2015, 1984) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2047, 2016)
			{
				int hls_map_index = 0;
				// celement: d_in.B(31, 0)
				{
					// carray: (63) => (262143) @ (64)
					for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_in.B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_in.B[0]
						// regulate_c_name       : d_in_B
						// input_type_conversion : d_in.B[i_0]
						if (&(d_in.B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_in_B_tmp_mem;
							d_in_B_tmp_mem = d_in.B[i_0];
							d_in_B_tvin_wrapc_buffer[hls_map_index].range(2047, 2016) = d_in_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 4096; i++)
		{
			sprintf(tvin_d_in_B, "%s\n", (d_in_B_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_d_in_B, tvin_d_in_B);
		}

		tcl_file.set_num(4096, &tcl_file.d_in_B_depth);
		sprintf(tvin_d_in_B, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_d_in_B, tvin_d_in_B);

		// release memory allocation
		delete [] d_in_B_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_d_out_A, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_d_out_A, tvin_d_out_A);

		sc_bv<2048>* d_out_A_tvin_wrapc_buffer = new sc_bv<2048>[4096];

		// RTL Name: d_out_A
		{
			// bitslice(31, 0)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (0) => (262080) @ (64)
					for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(31, 0) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(63, 32)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (1) => (262081) @ (64)
					for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(63, 32) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(95, 64)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (2) => (262082) @ (64)
					for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(95, 64) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(127, 96)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (3) => (262083) @ (64)
					for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(127, 96) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(159, 128)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (4) => (262084) @ (64)
					for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(159, 128) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(191, 160)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (5) => (262085) @ (64)
					for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(191, 160) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(223, 192)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (6) => (262086) @ (64)
					for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(223, 192) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(255, 224)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (7) => (262087) @ (64)
					for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(255, 224) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(287, 256)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (8) => (262088) @ (64)
					for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(287, 256) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(319, 288)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (9) => (262089) @ (64)
					for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(319, 288) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(351, 320)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (10) => (262090) @ (64)
					for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(351, 320) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(383, 352)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (11) => (262091) @ (64)
					for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(383, 352) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(415, 384)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (12) => (262092) @ (64)
					for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(415, 384) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(447, 416)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (13) => (262093) @ (64)
					for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(447, 416) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(479, 448)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (14) => (262094) @ (64)
					for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(479, 448) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(511, 480)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (15) => (262095) @ (64)
					for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(511, 480) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(543, 512)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (16) => (262096) @ (64)
					for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(543, 512) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(575, 544)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (17) => (262097) @ (64)
					for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(575, 544) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(607, 576)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (18) => (262098) @ (64)
					for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(607, 576) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(639, 608)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (19) => (262099) @ (64)
					for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(639, 608) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(671, 640)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (20) => (262100) @ (64)
					for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(671, 640) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(703, 672)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (21) => (262101) @ (64)
					for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(703, 672) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(735, 704)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (22) => (262102) @ (64)
					for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(735, 704) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(767, 736)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (23) => (262103) @ (64)
					for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(767, 736) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(799, 768)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (24) => (262104) @ (64)
					for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(799, 768) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(831, 800)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (25) => (262105) @ (64)
					for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(831, 800) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(863, 832)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (26) => (262106) @ (64)
					for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(863, 832) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(895, 864)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (27) => (262107) @ (64)
					for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(895, 864) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(927, 896)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (28) => (262108) @ (64)
					for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(927, 896) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(959, 928)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (29) => (262109) @ (64)
					for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(959, 928) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(991, 960)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (30) => (262110) @ (64)
					for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(991, 960) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1023, 992)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (31) => (262111) @ (64)
					for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1023, 992) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1055, 1024)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (32) => (262112) @ (64)
					for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1055, 1024) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1087, 1056)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (33) => (262113) @ (64)
					for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1087, 1056) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1119, 1088)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (34) => (262114) @ (64)
					for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1119, 1088) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1151, 1120)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (35) => (262115) @ (64)
					for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1151, 1120) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1183, 1152)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (36) => (262116) @ (64)
					for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1183, 1152) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1215, 1184)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (37) => (262117) @ (64)
					for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1215, 1184) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1247, 1216)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (38) => (262118) @ (64)
					for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1247, 1216) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1279, 1248)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (39) => (262119) @ (64)
					for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1279, 1248) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1311, 1280)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (40) => (262120) @ (64)
					for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1311, 1280) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1343, 1312)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (41) => (262121) @ (64)
					for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1343, 1312) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1375, 1344)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (42) => (262122) @ (64)
					for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1375, 1344) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1407, 1376)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (43) => (262123) @ (64)
					for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1407, 1376) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1439, 1408)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (44) => (262124) @ (64)
					for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1439, 1408) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1471, 1440)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (45) => (262125) @ (64)
					for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1471, 1440) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1503, 1472)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (46) => (262126) @ (64)
					for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1503, 1472) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1535, 1504)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (47) => (262127) @ (64)
					for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1535, 1504) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1567, 1536)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (48) => (262128) @ (64)
					for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1567, 1536) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1599, 1568)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (49) => (262129) @ (64)
					for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1599, 1568) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1631, 1600)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (50) => (262130) @ (64)
					for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1631, 1600) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1663, 1632)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (51) => (262131) @ (64)
					for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1663, 1632) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1695, 1664)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (52) => (262132) @ (64)
					for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1695, 1664) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1727, 1696)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (53) => (262133) @ (64)
					for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1727, 1696) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1759, 1728)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (54) => (262134) @ (64)
					for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1759, 1728) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1791, 1760)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (55) => (262135) @ (64)
					for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1791, 1760) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1823, 1792)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (56) => (262136) @ (64)
					for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1823, 1792) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1855, 1824)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (57) => (262137) @ (64)
					for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1855, 1824) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1887, 1856)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (58) => (262138) @ (64)
					for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1887, 1856) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1919, 1888)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (59) => (262139) @ (64)
					for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1919, 1888) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1951, 1920)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (60) => (262140) @ (64)
					for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1951, 1920) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1983, 1952)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (61) => (262141) @ (64)
					for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(1983, 1952) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2015, 1984)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (62) => (262142) @ (64)
					for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(2015, 1984) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2047, 2016)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (63) => (262143) @ (64)
					for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvin_wrapc_buffer[hls_map_index].range(2047, 2016) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 4096; i++)
		{
			sprintf(tvin_d_out_A, "%s\n", (d_out_A_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_d_out_A, tvin_d_out_A);
		}

		tcl_file.set_num(4096, &tcl_file.d_out_A_depth);
		sprintf(tvin_d_out_A, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_d_out_A, tvin_d_out_A);

		// release memory allocation
		delete [] d_out_A_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_d_out_B, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_d_out_B, tvin_d_out_B);

		sc_bv<2048>* d_out_B_tvin_wrapc_buffer = new sc_bv<2048>[4096];

		// RTL Name: d_out_B
		{
			// bitslice(31, 0)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (0) => (262080) @ (64)
					for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(31, 0) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(63, 32)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (1) => (262081) @ (64)
					for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(63, 32) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(95, 64)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (2) => (262082) @ (64)
					for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(95, 64) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(127, 96)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (3) => (262083) @ (64)
					for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(127, 96) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(159, 128)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (4) => (262084) @ (64)
					for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(159, 128) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(191, 160)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (5) => (262085) @ (64)
					for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(191, 160) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(223, 192)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (6) => (262086) @ (64)
					for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(223, 192) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(255, 224)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (7) => (262087) @ (64)
					for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(255, 224) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(287, 256)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (8) => (262088) @ (64)
					for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(287, 256) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(319, 288)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (9) => (262089) @ (64)
					for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(319, 288) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(351, 320)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (10) => (262090) @ (64)
					for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(351, 320) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(383, 352)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (11) => (262091) @ (64)
					for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(383, 352) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(415, 384)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (12) => (262092) @ (64)
					for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(415, 384) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(447, 416)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (13) => (262093) @ (64)
					for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(447, 416) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(479, 448)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (14) => (262094) @ (64)
					for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(479, 448) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(511, 480)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (15) => (262095) @ (64)
					for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(511, 480) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(543, 512)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (16) => (262096) @ (64)
					for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(543, 512) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(575, 544)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (17) => (262097) @ (64)
					for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(575, 544) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(607, 576)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (18) => (262098) @ (64)
					for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(607, 576) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(639, 608)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (19) => (262099) @ (64)
					for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(639, 608) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(671, 640)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (20) => (262100) @ (64)
					for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(671, 640) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(703, 672)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (21) => (262101) @ (64)
					for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(703, 672) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(735, 704)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (22) => (262102) @ (64)
					for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(735, 704) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(767, 736)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (23) => (262103) @ (64)
					for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(767, 736) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(799, 768)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (24) => (262104) @ (64)
					for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(799, 768) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(831, 800)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (25) => (262105) @ (64)
					for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(831, 800) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(863, 832)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (26) => (262106) @ (64)
					for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(863, 832) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(895, 864)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (27) => (262107) @ (64)
					for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(895, 864) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(927, 896)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (28) => (262108) @ (64)
					for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(927, 896) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(959, 928)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (29) => (262109) @ (64)
					for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(959, 928) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(991, 960)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (30) => (262110) @ (64)
					for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(991, 960) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1023, 992)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (31) => (262111) @ (64)
					for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1023, 992) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1055, 1024)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (32) => (262112) @ (64)
					for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1055, 1024) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1087, 1056)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (33) => (262113) @ (64)
					for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1087, 1056) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1119, 1088)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (34) => (262114) @ (64)
					for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1119, 1088) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1151, 1120)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (35) => (262115) @ (64)
					for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1151, 1120) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1183, 1152)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (36) => (262116) @ (64)
					for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1183, 1152) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1215, 1184)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (37) => (262117) @ (64)
					for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1215, 1184) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1247, 1216)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (38) => (262118) @ (64)
					for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1247, 1216) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1279, 1248)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (39) => (262119) @ (64)
					for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1279, 1248) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1311, 1280)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (40) => (262120) @ (64)
					for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1311, 1280) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1343, 1312)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (41) => (262121) @ (64)
					for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1343, 1312) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1375, 1344)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (42) => (262122) @ (64)
					for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1375, 1344) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1407, 1376)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (43) => (262123) @ (64)
					for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1407, 1376) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1439, 1408)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (44) => (262124) @ (64)
					for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1439, 1408) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1471, 1440)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (45) => (262125) @ (64)
					for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1471, 1440) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1503, 1472)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (46) => (262126) @ (64)
					for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1503, 1472) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1535, 1504)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (47) => (262127) @ (64)
					for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1535, 1504) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1567, 1536)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (48) => (262128) @ (64)
					for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1567, 1536) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1599, 1568)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (49) => (262129) @ (64)
					for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1599, 1568) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1631, 1600)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (50) => (262130) @ (64)
					for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1631, 1600) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1663, 1632)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (51) => (262131) @ (64)
					for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1663, 1632) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1695, 1664)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (52) => (262132) @ (64)
					for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1695, 1664) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1727, 1696)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (53) => (262133) @ (64)
					for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1727, 1696) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1759, 1728)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (54) => (262134) @ (64)
					for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1759, 1728) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1791, 1760)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (55) => (262135) @ (64)
					for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1791, 1760) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1823, 1792)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (56) => (262136) @ (64)
					for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1823, 1792) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1855, 1824)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (57) => (262137) @ (64)
					for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1855, 1824) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1887, 1856)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (58) => (262138) @ (64)
					for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1887, 1856) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1919, 1888)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (59) => (262139) @ (64)
					for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1919, 1888) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1951, 1920)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (60) => (262140) @ (64)
					for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1951, 1920) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1983, 1952)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (61) => (262141) @ (64)
					for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(1983, 1952) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2015, 1984)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (62) => (262142) @ (64)
					for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(2015, 1984) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2047, 2016)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (63) => (262143) @ (64)
					for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvin_wrapc_buffer[hls_map_index].range(2047, 2016) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 4096; i++)
		{
			sprintf(tvin_d_out_B, "%s\n", (d_out_B_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_d_out_B, tvin_d_out_B);
		}

		tcl_file.set_num(4096, &tcl_file.d_out_B_depth);
		sprintf(tvin_d_out_B, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_d_out_B, tvin_d_out_B);

		// release memory allocation
		delete [] d_out_B_tvin_wrapc_buffer;

// [call_c_dut] ---------->

		CodeState = CALL_C_DUT;
		lab5_z3(d_in, d_out);

		CodeState = DUMP_OUTPUTS;

		// [[transaction]]
		sprintf(tvout_d_out_A, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_d_out_A, tvout_d_out_A);

		sc_bv<2048>* d_out_A_tvout_wrapc_buffer = new sc_bv<2048>[4096];

		// RTL Name: d_out_A
		{
			// bitslice(31, 0)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (0) => (262080) @ (64)
					for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(31, 0) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(63, 32)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (1) => (262081) @ (64)
					for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(63, 32) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(95, 64)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (2) => (262082) @ (64)
					for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(95, 64) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(127, 96)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (3) => (262083) @ (64)
					for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(127, 96) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(159, 128)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (4) => (262084) @ (64)
					for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(159, 128) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(191, 160)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (5) => (262085) @ (64)
					for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(191, 160) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(223, 192)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (6) => (262086) @ (64)
					for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(223, 192) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(255, 224)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (7) => (262087) @ (64)
					for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(255, 224) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(287, 256)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (8) => (262088) @ (64)
					for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(287, 256) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(319, 288)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (9) => (262089) @ (64)
					for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(319, 288) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(351, 320)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (10) => (262090) @ (64)
					for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(351, 320) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(383, 352)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (11) => (262091) @ (64)
					for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(383, 352) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(415, 384)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (12) => (262092) @ (64)
					for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(415, 384) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(447, 416)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (13) => (262093) @ (64)
					for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(447, 416) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(479, 448)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (14) => (262094) @ (64)
					for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(479, 448) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(511, 480)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (15) => (262095) @ (64)
					for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(511, 480) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(543, 512)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (16) => (262096) @ (64)
					for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(543, 512) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(575, 544)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (17) => (262097) @ (64)
					for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(575, 544) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(607, 576)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (18) => (262098) @ (64)
					for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(607, 576) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(639, 608)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (19) => (262099) @ (64)
					for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(639, 608) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(671, 640)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (20) => (262100) @ (64)
					for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(671, 640) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(703, 672)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (21) => (262101) @ (64)
					for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(703, 672) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(735, 704)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (22) => (262102) @ (64)
					for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(735, 704) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(767, 736)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (23) => (262103) @ (64)
					for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(767, 736) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(799, 768)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (24) => (262104) @ (64)
					for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(799, 768) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(831, 800)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (25) => (262105) @ (64)
					for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(831, 800) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(863, 832)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (26) => (262106) @ (64)
					for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(863, 832) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(895, 864)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (27) => (262107) @ (64)
					for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(895, 864) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(927, 896)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (28) => (262108) @ (64)
					for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(927, 896) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(959, 928)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (29) => (262109) @ (64)
					for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(959, 928) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(991, 960)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (30) => (262110) @ (64)
					for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(991, 960) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1023, 992)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (31) => (262111) @ (64)
					for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1023, 992) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1055, 1024)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (32) => (262112) @ (64)
					for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1055, 1024) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1087, 1056)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (33) => (262113) @ (64)
					for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1087, 1056) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1119, 1088)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (34) => (262114) @ (64)
					for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1119, 1088) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1151, 1120)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (35) => (262115) @ (64)
					for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1151, 1120) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1183, 1152)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (36) => (262116) @ (64)
					for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1183, 1152) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1215, 1184)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (37) => (262117) @ (64)
					for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1215, 1184) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1247, 1216)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (38) => (262118) @ (64)
					for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1247, 1216) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1279, 1248)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (39) => (262119) @ (64)
					for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1279, 1248) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1311, 1280)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (40) => (262120) @ (64)
					for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1311, 1280) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1343, 1312)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (41) => (262121) @ (64)
					for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1343, 1312) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1375, 1344)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (42) => (262122) @ (64)
					for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1375, 1344) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1407, 1376)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (43) => (262123) @ (64)
					for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1407, 1376) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1439, 1408)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (44) => (262124) @ (64)
					for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1439, 1408) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1471, 1440)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (45) => (262125) @ (64)
					for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1471, 1440) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1503, 1472)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (46) => (262126) @ (64)
					for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1503, 1472) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1535, 1504)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (47) => (262127) @ (64)
					for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1535, 1504) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1567, 1536)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (48) => (262128) @ (64)
					for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1567, 1536) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1599, 1568)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (49) => (262129) @ (64)
					for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1599, 1568) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1631, 1600)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (50) => (262130) @ (64)
					for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1631, 1600) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1663, 1632)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (51) => (262131) @ (64)
					for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1663, 1632) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1695, 1664)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (52) => (262132) @ (64)
					for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1695, 1664) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1727, 1696)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (53) => (262133) @ (64)
					for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1727, 1696) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1759, 1728)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (54) => (262134) @ (64)
					for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1759, 1728) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1791, 1760)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (55) => (262135) @ (64)
					for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1791, 1760) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1823, 1792)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (56) => (262136) @ (64)
					for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1823, 1792) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1855, 1824)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (57) => (262137) @ (64)
					for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1855, 1824) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1887, 1856)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (58) => (262138) @ (64)
					for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1887, 1856) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1919, 1888)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (59) => (262139) @ (64)
					for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1919, 1888) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1951, 1920)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (60) => (262140) @ (64)
					for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1951, 1920) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1983, 1952)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (61) => (262141) @ (64)
					for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(1983, 1952) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2015, 1984)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (62) => (262142) @ (64)
					for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(2015, 1984) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2047, 2016)
			{
				int hls_map_index = 0;
				// celement: d_out.A(31, 0)
				{
					// carray: (63) => (262143) @ (64)
					for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->A[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->A[0]
						// regulate_c_name       : d_out_A
						// input_type_conversion : d_out->A[i_0]
						if (&(d_out->A[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_A_tmp_mem;
							d_out_A_tmp_mem = d_out->A[i_0];
							d_out_A_tvout_wrapc_buffer[hls_map_index].range(2047, 2016) = d_out_A_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 4096; i++)
		{
			sprintf(tvout_d_out_A, "%s\n", (d_out_A_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_d_out_A, tvout_d_out_A);
		}

		tcl_file.set_num(4096, &tcl_file.d_out_A_depth);
		sprintf(tvout_d_out_A, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_d_out_A, tvout_d_out_A);

		// release memory allocation
		delete [] d_out_A_tvout_wrapc_buffer;

		// [[transaction]]
		sprintf(tvout_d_out_B, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_d_out_B, tvout_d_out_B);

		sc_bv<2048>* d_out_B_tvout_wrapc_buffer = new sc_bv<2048>[4096];

		// RTL Name: d_out_B
		{
			// bitslice(31, 0)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (0) => (262080) @ (64)
					for (int i_0 = 0; i_0 <= 262080; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(31, 0) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(63, 32)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (1) => (262081) @ (64)
					for (int i_0 = 1; i_0 <= 262081; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(63, 32) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(95, 64)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (2) => (262082) @ (64)
					for (int i_0 = 2; i_0 <= 262082; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(95, 64) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(127, 96)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (3) => (262083) @ (64)
					for (int i_0 = 3; i_0 <= 262083; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(127, 96) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(159, 128)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (4) => (262084) @ (64)
					for (int i_0 = 4; i_0 <= 262084; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(159, 128) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(191, 160)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (5) => (262085) @ (64)
					for (int i_0 = 5; i_0 <= 262085; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(191, 160) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(223, 192)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (6) => (262086) @ (64)
					for (int i_0 = 6; i_0 <= 262086; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(223, 192) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(255, 224)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (7) => (262087) @ (64)
					for (int i_0 = 7; i_0 <= 262087; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(255, 224) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(287, 256)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (8) => (262088) @ (64)
					for (int i_0 = 8; i_0 <= 262088; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(287, 256) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(319, 288)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (9) => (262089) @ (64)
					for (int i_0 = 9; i_0 <= 262089; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(319, 288) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(351, 320)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (10) => (262090) @ (64)
					for (int i_0 = 10; i_0 <= 262090; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(351, 320) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(383, 352)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (11) => (262091) @ (64)
					for (int i_0 = 11; i_0 <= 262091; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(383, 352) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(415, 384)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (12) => (262092) @ (64)
					for (int i_0 = 12; i_0 <= 262092; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(415, 384) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(447, 416)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (13) => (262093) @ (64)
					for (int i_0 = 13; i_0 <= 262093; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(447, 416) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(479, 448)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (14) => (262094) @ (64)
					for (int i_0 = 14; i_0 <= 262094; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(479, 448) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(511, 480)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (15) => (262095) @ (64)
					for (int i_0 = 15; i_0 <= 262095; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(511, 480) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(543, 512)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (16) => (262096) @ (64)
					for (int i_0 = 16; i_0 <= 262096; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(543, 512) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(575, 544)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (17) => (262097) @ (64)
					for (int i_0 = 17; i_0 <= 262097; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(575, 544) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(607, 576)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (18) => (262098) @ (64)
					for (int i_0 = 18; i_0 <= 262098; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(607, 576) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(639, 608)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (19) => (262099) @ (64)
					for (int i_0 = 19; i_0 <= 262099; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(639, 608) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(671, 640)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (20) => (262100) @ (64)
					for (int i_0 = 20; i_0 <= 262100; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(671, 640) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(703, 672)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (21) => (262101) @ (64)
					for (int i_0 = 21; i_0 <= 262101; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(703, 672) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(735, 704)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (22) => (262102) @ (64)
					for (int i_0 = 22; i_0 <= 262102; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(735, 704) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(767, 736)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (23) => (262103) @ (64)
					for (int i_0 = 23; i_0 <= 262103; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(767, 736) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(799, 768)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (24) => (262104) @ (64)
					for (int i_0 = 24; i_0 <= 262104; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(799, 768) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(831, 800)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (25) => (262105) @ (64)
					for (int i_0 = 25; i_0 <= 262105; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(831, 800) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(863, 832)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (26) => (262106) @ (64)
					for (int i_0 = 26; i_0 <= 262106; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(863, 832) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(895, 864)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (27) => (262107) @ (64)
					for (int i_0 = 27; i_0 <= 262107; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(895, 864) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(927, 896)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (28) => (262108) @ (64)
					for (int i_0 = 28; i_0 <= 262108; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(927, 896) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(959, 928)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (29) => (262109) @ (64)
					for (int i_0 = 29; i_0 <= 262109; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(959, 928) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(991, 960)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (30) => (262110) @ (64)
					for (int i_0 = 30; i_0 <= 262110; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(991, 960) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1023, 992)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (31) => (262111) @ (64)
					for (int i_0 = 31; i_0 <= 262111; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1023, 992) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1055, 1024)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (32) => (262112) @ (64)
					for (int i_0 = 32; i_0 <= 262112; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1055, 1024) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1087, 1056)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (33) => (262113) @ (64)
					for (int i_0 = 33; i_0 <= 262113; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1087, 1056) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1119, 1088)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (34) => (262114) @ (64)
					for (int i_0 = 34; i_0 <= 262114; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1119, 1088) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1151, 1120)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (35) => (262115) @ (64)
					for (int i_0 = 35; i_0 <= 262115; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1151, 1120) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1183, 1152)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (36) => (262116) @ (64)
					for (int i_0 = 36; i_0 <= 262116; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1183, 1152) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1215, 1184)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (37) => (262117) @ (64)
					for (int i_0 = 37; i_0 <= 262117; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1215, 1184) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1247, 1216)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (38) => (262118) @ (64)
					for (int i_0 = 38; i_0 <= 262118; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1247, 1216) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1279, 1248)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (39) => (262119) @ (64)
					for (int i_0 = 39; i_0 <= 262119; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1279, 1248) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1311, 1280)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (40) => (262120) @ (64)
					for (int i_0 = 40; i_0 <= 262120; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1311, 1280) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1343, 1312)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (41) => (262121) @ (64)
					for (int i_0 = 41; i_0 <= 262121; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1343, 1312) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1375, 1344)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (42) => (262122) @ (64)
					for (int i_0 = 42; i_0 <= 262122; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1375, 1344) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1407, 1376)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (43) => (262123) @ (64)
					for (int i_0 = 43; i_0 <= 262123; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1407, 1376) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1439, 1408)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (44) => (262124) @ (64)
					for (int i_0 = 44; i_0 <= 262124; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1439, 1408) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1471, 1440)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (45) => (262125) @ (64)
					for (int i_0 = 45; i_0 <= 262125; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1471, 1440) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1503, 1472)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (46) => (262126) @ (64)
					for (int i_0 = 46; i_0 <= 262126; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1503, 1472) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1535, 1504)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (47) => (262127) @ (64)
					for (int i_0 = 47; i_0 <= 262127; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1535, 1504) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1567, 1536)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (48) => (262128) @ (64)
					for (int i_0 = 48; i_0 <= 262128; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1567, 1536) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1599, 1568)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (49) => (262129) @ (64)
					for (int i_0 = 49; i_0 <= 262129; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1599, 1568) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1631, 1600)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (50) => (262130) @ (64)
					for (int i_0 = 50; i_0 <= 262130; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1631, 1600) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1663, 1632)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (51) => (262131) @ (64)
					for (int i_0 = 51; i_0 <= 262131; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1663, 1632) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1695, 1664)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (52) => (262132) @ (64)
					for (int i_0 = 52; i_0 <= 262132; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1695, 1664) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1727, 1696)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (53) => (262133) @ (64)
					for (int i_0 = 53; i_0 <= 262133; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1727, 1696) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1759, 1728)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (54) => (262134) @ (64)
					for (int i_0 = 54; i_0 <= 262134; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1759, 1728) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1791, 1760)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (55) => (262135) @ (64)
					for (int i_0 = 55; i_0 <= 262135; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1791, 1760) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1823, 1792)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (56) => (262136) @ (64)
					for (int i_0 = 56; i_0 <= 262136; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1823, 1792) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1855, 1824)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (57) => (262137) @ (64)
					for (int i_0 = 57; i_0 <= 262137; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1855, 1824) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1887, 1856)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (58) => (262138) @ (64)
					for (int i_0 = 58; i_0 <= 262138; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1887, 1856) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1919, 1888)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (59) => (262139) @ (64)
					for (int i_0 = 59; i_0 <= 262139; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1919, 1888) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1951, 1920)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (60) => (262140) @ (64)
					for (int i_0 = 60; i_0 <= 262140; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1951, 1920) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(1983, 1952)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (61) => (262141) @ (64)
					for (int i_0 = 61; i_0 <= 262141; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(1983, 1952) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2015, 1984)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (62) => (262142) @ (64)
					for (int i_0 = 62; i_0 <= 262142; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(2015, 1984) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
			// bitslice(2047, 2016)
			{
				int hls_map_index = 0;
				// celement: d_out.B(31, 0)
				{
					// carray: (63) => (262143) @ (64)
					for (int i_0 = 63; i_0 <= 262143; i_0 += 64)
					{
						// sub                   : i_0
						// ori_name              : d_out->B[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : d_out->B[0]
						// regulate_c_name       : d_out_B
						// input_type_conversion : d_out->B[i_0]
						if (&(d_out->B[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> d_out_B_tmp_mem;
							d_out_B_tmp_mem = d_out->B[i_0];
							d_out_B_tvout_wrapc_buffer[hls_map_index].range(2047, 2016) = d_out_B_tmp_mem.range(31, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 4096; i++)
		{
			sprintf(tvout_d_out_B, "%s\n", (d_out_B_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_d_out_B, tvout_d_out_B);
		}

		tcl_file.set_num(4096, &tcl_file.d_out_B_depth);
		sprintf(tvout_d_out_B, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_d_out_B, tvout_d_out_B);

		// release memory allocation
		delete [] d_out_B_tvout_wrapc_buffer;

		CodeState = DELETE_CHAR_BUFFERS;
		// release memory allocation: "d_in_A"
		delete [] tvin_d_in_A;
		// release memory allocation: "d_in_B"
		delete [] tvin_d_in_B;
		// release memory allocation: "d_out_A"
		delete [] tvout_d_out_A;
		delete [] tvin_d_out_A;
		// release memory allocation: "d_out_B"
		delete [] tvout_d_out_B;
		delete [] tvin_d_out_B;

		AESL_transaction++;

		tcl_file.set_num(AESL_transaction , &tcl_file.trans_num);
	}
}

