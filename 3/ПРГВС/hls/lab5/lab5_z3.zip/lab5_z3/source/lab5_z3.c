#include "lab5_z3.h"

void lab5_z3(data d_in, data* d_out)
{
	looplabel0: for(int i = 0; i < N; ++i) {
		d_out->A[i] = d_in.A[i] + d_in.B[i];
		d_out->B[i] = d_in.A[i] - d_in.B[i];
	}

}


