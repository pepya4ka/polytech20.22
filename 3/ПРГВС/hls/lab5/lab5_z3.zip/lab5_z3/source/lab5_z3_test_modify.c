#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "lab5_z3.h"

int cmp_arr(data d_in, data* d_cmp)
{
	for(int i = 0; i < N; ++i) {
		int tmp1 = d_in.A[i] + d_in.B[i];
		int tmp2 = d_in.A[i] - d_in.B[i];
		if (d_cmp->A[i] != tmp1 || d_cmp->B[i] != tmp2)
			return 0;
	}

	return 1;
}
 

int main()
{
	int pass=0;

	// Call the function for 32 transactions
	data d_in;
	data d_out;
	struct timespec t0, t1;
	double acc_time = 0.0;

	for (int i = 0; i < 32; ++i){
		for(int j = 0; j < N; j++){
			d_in.A[j] = rand() % (N - 1) + 1;
			d_in.B[j] = (rand() + (rand()/2 +1)) % (N - 1) + 1;
		}
		
		if(clock_gettime(CLOCK_REALTIME, &t0) != 0) {
			perror("Error in calling clock_gettime\n");
         	exit(EXIT_FAILURE);
     	}
		lab5_z3(d_in, &d_out);
		if(clock_gettime(CLOCK_REALTIME, &t1) != 0) {
         	perror("Error in calling clock_gettime\n");
         	exit(EXIT_FAILURE);
     	}
     	double diff_time = (((double)(t1.tv_sec - t0.tv_sec))*1000000000.0) + (double)(t1.tv_nsec - t0.tv_nsec);
		acc_time += diff_time;
		double temp_avg_time = acc_time / (i + 1); // take average time
		printf("Elapsed time: %.4lf nanoseconds\n", temp_avg_time);
		
		pass = cmp_arr(d_in, &d_out);
		if (pass == 0)	{
			fprintf(stderr, "----------Fail!------------\n");
			return 1;
		}
	}

	
	fprintf(stdout, "----------Pass!------------\n");
	return 0;	
}

