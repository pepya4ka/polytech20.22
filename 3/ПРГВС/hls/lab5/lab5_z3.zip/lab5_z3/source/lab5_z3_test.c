#include <stdio.h>
#include "lab5_z3.h"
 
 
int cmp_arr(data d_in, data* d_cmp)
{
	for(int i = 0; i < N; ++i) {
		int tmp1 = d_in.A[i] + d_in.B[i];
		int tmp2 = d_in.A[i] - d_in.B[i];
		if (d_cmp->A[i] != tmp1 || d_cmp->B[i] != tmp2)
			return 0;
	}

	return 1;
}
 
 
int main () {

	int pass = 0;
	// Create input data
	data d_in;
	data d_out;

	for (int i = 0; i < 3; ++i){
		for(int j = 0; j < N; j++){
			d_in.A[j] = rand() % (N - 1) + 1;
			d_in.B[j] = (rand() + (rand()/2 +1)) % (N - 1) + 1;
		}
		
		
		lab5_z3(d_in, &d_out);
		pass = cmp_arr(d_in, &d_out);
		if (pass == 0) {
			fprintf(stderr, "----------Fail!------------\n");
			return 1;
		}
	}
	

	
	fprintf(stdout, "----------Pass!------------\n");
	return 0;

}
