#ifndef LAB5_Z3_H_
#define LAB5_Z3_H_
 
#include <stdio.h>

#define N 262144
typedef struct {
	int A[N];
	int B[N];
} data;


void lab5_z3(data d_in, data* d_out);

#endif
