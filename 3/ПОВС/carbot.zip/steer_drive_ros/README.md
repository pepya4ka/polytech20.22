# steer_drive_ros [![Build Status](https://travis-ci.org/CIR-KIT/steer_drive_ros.svg?branch=lunar-devel)](https://travis-ci.org/CIR-KIT/steer_drive_ros) [![Slack](https://img.shields.io/badge/Slack-CIR--KIT-blue.svg)](http://cir-kit.slack.com/messages/steer_drive_ros)
Steer drive package for ROS



| Package | Indigo | Jade | Kinetic | Lunar |
|:-------:|:------:|:----:|:-------:|:-----:|
|  Status | [![Build Status](https://travis-ci.org/CIR-KIT/steer_drive_ros.svg?branch=indigo-devel)](https://travis-ci.org/CIR-KIT/steer_drive_ros)  | [![Build Status](https://travis-ci.org/CIR-KIT/steer_drive_ros.svg?branch=jade-devel)](https://travis-ci.org/CIR-KIT/steer_drive_ros) | [![Build Status](https://travis-ci.org/CIR-KIT/steer_drive_ros.svg?branch=kinetic-devel)](https://travis-ci.org/CIR-KIT/steer_drive_ros) | [![Build Status](https://travis-ci.org/CIR-KIT/steer_drive_ros.svg?branch=lunar-devel)](https://travis-ci.org/CIR-KIT/steer_drive_ros) |

See [steer_drive_ros documentation](http://wiki.ros.org/steer_drive_ros) on ros.org
